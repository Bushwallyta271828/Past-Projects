from __future__ import division
from pylab import *
import call
from scipy.optimize import minimize

def f(points, *args):
	amplification = call.call(points)
	n = args[0]
	value_output = open("./output/output" + str(n) + "values.txt")
	lines = value_output.readlines()
	value_output.close()
	value_outputw = open("./output/output" + str(n) + "values.txt", "w")
	for line in lines:
		value_outputw.write(line)
	value_outputw.write(str(amplification) + "\n")
	value_outputw.close()
	points_output = open("./output/output" + str(n) + "points.txt")
	lines = points_output.readlines()
	points_output.close()
	points_outputw = open("./output/output" + str(n) + "points.txt", "w")
	for line in lines:
		points_outputw.write(line)
	points_outputw.write(str(points) + "\n")
	points_outputw.close()
	return -amplification

n = 20
population_size = 20
population = []
for i in range(population_size):
	member = [random() for i in range(n)]
	population.append(member)
bound = [(0, 1) for i in range(n)]
values = {}
for membernumber, member in enumerate(population):
	first_line_values = open("./output/output" + str(membernumber) + "values.txt", "w")
	first_line_values.write("0\n")
	first_line_values.close()
	first_line_points = open("./output/output" + str(membernumber) + "points.txt", "w")
	first_line_points.write(str(member) + "\n")
	first_line_points.close()
	result = minimize(fun=f, x0=member, args=([membernumber]), method="TNC", bounds=bound, tol=10**(-10))
	values[tuple(member)] = result.fun
best = -1
points = [-1]
for member in population:
	if values[member] > best:
		best = values[member]
		points = member

print "\n\n\n"
print "BEST VALUE"
print best
print "BEST POINTS"
print points
