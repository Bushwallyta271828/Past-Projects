from __future__ import division
from pylab import *
import Solution
import fun_gen

n = 10
population_size = 10
iterations = 10

population = []
for i in range(population_size):
	solution = fun_gen.fun_gen(n)
	population.append(solution)
for i in range(iterations):
	
