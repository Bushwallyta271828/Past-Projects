from __future__ import division
from pylab import *

args = sys.argv[1:]
if len(args) == 0:
	n = 0
	feature = ""
elif len(args) == 1:
	feature = args[0]
	n = 0
elif len(args) == 2:
	feature = args[0]
	n = int(args[1])

data = open("./output/" + str(n) + ".txt")
lines = data.readlines()
data.close()
values = []
for line in lines:
	real_line = line[:-1]
	value = float(real_line)
	values.append(value)

if feature != "log":
	plot(values)
	show()

if feature != "reg":
	plot(log10(values))
	show()
