from __future__ import division
from pylab import *

def generate_shape(n):
	deviation = 0.2
	n = 50
	member = [1]
	for i in range(n - 1):
                last = member[-1]
                upper_bound = (1 - last)*deviation*(n + 1 - i)/(n + 1) + last
                lower_bound = last - last*deviation*(i + 1)/(n + 1)
                value = (upper_bound - lower_bound)*random() + lower_bound
                member.append(value)
	return member

for i in range(10):
	shape = generate_shape(i)
	plot(shape)
	show()
