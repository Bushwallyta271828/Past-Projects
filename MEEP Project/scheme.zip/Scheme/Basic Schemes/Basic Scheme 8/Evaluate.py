from __future__ import division
from pylab import *
import call

def evaluate(points, *args):
	maxholder = args[0]
	value = call.call(points)
	if value > maxholder.x:
		maxholder.x = value
	return value
