from __future__ import division
import os

def call(res, points):
	os.system('cd ..; cd "MEEP Project"; meep res=' + str(res) + ' THE_BLOODY_THING_WORKS.rkt > bar.txt')
	lines = open("/home/xander/Dropbox/Scheme/MEEP Project/bar.txt").readlines()
	line = lines[-1][:-1]
	number = float(line)
	return number

print call(50, [1, 0.75, 5, 0.25, 0])
