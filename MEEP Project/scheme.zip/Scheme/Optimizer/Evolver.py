from __future__ import division
import numpy as np
import pylab as pl
import Solution

def generate(solutions):
        solutions.sort(key = lambda x : x.amplification())
	tops = solutions[:len(solutions)//2]
	new_tops = tops[:]
	for top in tops:
		new_tops.append(top.breed2(tops[np.random.randint(0, len(tops))]))
	return new_tops

def amplify():
	number_of_initial_guesses = 10
	resolution = 150
	size = 20
	iterations = 20
	solutions = []
	for i in range(number_of_initial_guesses):
		solutions.append(Solution.Solution(resolution, np.random.uniform(0, 1, size)))
	for i in range(iterations):
		for solution in solutions:
			solution.mutate()
		solutions = generate(solutions)
	return solutions[0]


