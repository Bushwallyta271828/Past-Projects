from __future__ import division
from pylab import *

class Solution:
	def __init__(self, points):
		self.points = points

	def merge(self, other, method=1):
		if method == 1:
			newpoints = [self.points[i] + other.points[i] 
