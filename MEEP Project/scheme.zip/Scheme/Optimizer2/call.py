from __future__ import division
from pylab import *

def call(point):
	pass
