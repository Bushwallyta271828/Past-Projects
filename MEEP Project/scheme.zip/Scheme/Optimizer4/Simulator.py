from __future__ import division
from pylab import *
import call
from scipy.optimize import minimize

def f(points):
	return -call.call(points, res=75)

n = 20
points = [1 - (i + 0.5)/n for i in range(n)]
result = minimize(f, points, method="TNC", bounds=[(0, 1) for i in range(n)])
print result
