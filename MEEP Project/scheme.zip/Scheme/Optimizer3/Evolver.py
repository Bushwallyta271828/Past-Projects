from __future__ import division
from pylab import *
import Solution
import os
import glob

ROOT = "/home/xander/Dropbox/Scheme/Optimizer3"

def iterate(population, bests, lasts, dev, res):
	"""
	This function performs one iteration on the population.
	bests is the same bests as in evolver.
	lasts is a list of the previous improvements.
	dev is some measure of our deviation.
	"""
	#We sort the population by amplification and take the first bests*100 percent of the sample
	sorted_population = sorted(population, key=lambda solution: -solution(res))
	length = len(population)
	to_be_kept = sorted_population[:int(length*bests)]
	new_population = to_be_kept
	#We generate the new children
	for i in range(length - int(length*bests)):
		parent1 = to_be_kept[int(length*bests*random())]
		parent2 = to_be_kept[int(length*bests*random())]
		child = parent1.breed(parent2)
		new_population.append(child)
	#We mutate the population
	lasts.append(to_be_kept[0](res))
	for member in new_population:
		member.mutate("every", dev*(lasts[-1] - lasts[-2]))
	#We return our findings
	return new_population, lasts


def evolver(n, iterations, dev, keep_up=30, bests=0.5, res=75):
	"""
	This function finds the best funnel shape.
	n is the number of points on the funnel (INT)
	iterations is the number of iterations (INT)
	dev is some measure of how much we deviate our solutions (FLOAT)
	keep_up is the number of solutions to have in the breeding pool (INT)
	bests is the fraction of the population (the best of the population) that we keep alive after each iteration. (FLOAT)
	"""
	#We generate the population.
	#The members are randomly generated.
	population = []
	for i in range(keep_up):
		points = [random() for i in range(n)]
		solution = Solution.Solution(points)
		population.append(solution)
	#We delete any previous results
	if glob.glob(ROOT + "/output/*") != []:
		os.system("rm " + ROOT + "/output/*")
	#We evolve our population.
	lasts = []
	lasts.append(population[0](res))
	for i in range(iterations):
		print "iteration number : " + str(i)
		population, lasts = iterate(population, bests, lasts, dev, res)
		print population[0]
		print lasts[-1]
		f = open(ROOT + "/output/no" + str(i) + ".txt", "w")
		for member in population:
			f.write(str(member) + "\n")
		f.write(str(lasts[-1]) + "\n")
		f.close()
		print "\n"*10
	#We return the best member
	return population[0]

print evolver(20, 1000, 0.01)
