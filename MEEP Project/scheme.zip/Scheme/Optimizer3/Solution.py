from __future__ import division
from pylab import *
import call

class Solution:
	def __init__(self, points):
		self.points = points

	def breed(self, other, method="average"):
		if method == "average":
			points = [(self.points[i] + other.points[i])/2 for i in range(len(self.points))]
			solution = Solution(points)
			return solution
	
	def mutate(self, method="every", *extra):
		if method == "every":
			"""
			"extra" will only contain one item.
			It will be the deviation.
			"""
			dev = extra[0]
			for point_num, point in enumerate(self.points):
				new_value = self.points[point_num]
				new_value += dev * (1 - 2*random())
				if new_value < 0:
					new_value = 0
				elif new_value > 1:
					new_value = 1
				self.points[point_num] = new_value

	def __call__(self, res):
		return call.call(self.points, res)

	def __str__(self):
		string = "Solution("
		string += "points = "
		string += str(self.points)
		string += ")"
		return string
