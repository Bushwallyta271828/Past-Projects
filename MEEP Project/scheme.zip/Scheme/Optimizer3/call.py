from __future__ import division
from pylab import *
import os

ROOT = "/home/xander/Dropbox/Scheme"

def call(points, res=75):
	"""
	evaluates the amplification for some funnel.
	points is a list of the coordinates of the funnel. (LIST)
	res is the resolution used for the simulation (INT)
	"""
	os.system('meep res=' + str(res) + ' "' + ROOT + '/MEEP Project/THE_BLOODY_THING_WORKS.rkt" > ' + ROOT + '/Optimizer3/call_output.txt')
	f = open("call_output.txt")
	lines = f.readlines()
	f.close()
	line = lines[-1][:-1]
	result = float(line)
	return result
