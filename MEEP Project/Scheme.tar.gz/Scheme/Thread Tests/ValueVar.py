from __future__ import division
from pylab import *

class ValueVar:
	def __init__(self, x):
		self.x = x
