from __future__ import division
import numpy as np
import call

class Solution:
	def __init__(self, res, points):
		""" points is a list of the vertices of the planar objects.
		    points is a list of numbers from 0 to 1.
		    points should start near 1 and end near 0 to look like a funnel. """
		self.res = res
		self.points = points
		self.change_no = 2
		self.change_dist = 0.01

	def mutate(self):
		""" mutate(self) produces a mutated version of self """
		points = self.points
		indices = np.random.randint(0, high=len(points), size=self.change_no)
		for index in indices:
			self.points[index] += self.change_dist * np.random.uniform(-1, 1)
			if self.points[index] < 0:
				self.points[index] = 0
			elif self.points[index] > 1:
				self.points[index] = 1

	def breed1(self, other):
		""" This function takes the left half of self and merges it with the right half of other. """
		assert len(self.points) == len(other.points)
		self_left_half = self.points[:len(self.points)//2]
		other_right_half = other.points[len(other.points)//2:]
		merged = self_left_half + other_right_half
		return Solution(self.res, merged)


	def breed2(self, other):
		""" This function averages the y-coordinates of the two points, self and other. """
		assert len(self.points) == len(other.points)
		averaged_coordinates = [(self.points[i] + other.points[i])/2 for i in range(self.points)]
		return Solution(self.res, averaged_coordinates)

	def amplification(self):
		return call.call(self.res, self.points)
