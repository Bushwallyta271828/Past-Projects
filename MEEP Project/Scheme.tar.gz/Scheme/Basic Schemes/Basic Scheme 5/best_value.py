import glob

names = glob.glob("./output/*")
numbers = []
for name in names:
	f = open(name)
	lines = f.readlines()
	f.close()
	for line in lines:
		real_line = line[:-1]
		number = float(real_line)
		numbers.append(number)
print max(numbers)
