from __future__ import division
from pylab import *

class Val:
	def __init__(self, x):
		self.x = x
