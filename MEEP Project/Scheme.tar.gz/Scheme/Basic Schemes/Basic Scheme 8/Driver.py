from __future__ import division
from pylab import *
import Solution
