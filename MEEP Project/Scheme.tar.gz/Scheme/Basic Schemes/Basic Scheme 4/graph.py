from __future__ import division
from pylab import *

if len(sys.argv) == 2:
	n = int(sys.argv[1])
else:
	n = 0
data = open("./output/" + str(n) + ".txt")
lines = data.readlines()
data.close()
values = []
for line in lines:
	real_line = line[:-1]
	value = float(real_line)
	values.append(value)
plot(values)
show()

plot(log10(values))
show()
