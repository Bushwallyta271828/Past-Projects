from __future__ import division
from pylab import *
import call
from scipy.optimize import minimize

def f(points, *args):
	n = args[0]
	amplification = call.call(points)
	values = open("./output/" + str(n) + ".txt")
	lines = values.readlines()
	values.close()
	valuesw = open("./output/" + str(n) + ".txt", "w")
	for line in lines:
		valuesw.write(line)
	valuesw.write(str(amplification) + "\n")
	valuesw.close()
	return -amplification

n = 50
population_size = 20
population = random((population_size, n))
bound = [(0, 1) for i in range(n)]
values = {}
for membernum, member in enumerate(population):
	first_line = open("./output/" + str(membernum) + ".txt", "w")
	first_line.write(str(call.call(member)) + "\n")
	first_line.close()
	result = minimize(fun=f, x0=member, args=([membernum]), method="TNC", bounds=bound)
	values[tuple(member)] = result.fun
best = 1 #Remember, the function returns the NEGATIVE of the amplification
points = [-1]
for member in population:
	if values[member] < best:
		best = values[member]
		points = member

print "\n\n\n"
print "BEST VALUE"
print -best
print "BEST POINTS"
print points
