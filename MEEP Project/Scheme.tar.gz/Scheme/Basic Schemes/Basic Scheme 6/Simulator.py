from __future__ import division
from pylab import *
import call
from scipy.optimize import minimize

def f(points, *args):
	n = args[0]
	amplification = call.call(points)
	values = open("./output/" + str(n) + ".txt")
	lines = values.readlines()
	values.close()
	valuesw = open("./output/" + str(n) + ".txt", "w")
	for line in lines:
		valuesw.write(line)
	valuesw.write(str(amplification) + "\n")
	valuesw.close()
	return -amplification

n = 50
population_size = 10
deviation = 0.2
population = []
for i in range(population_size):
	member = [1]
	for i in range(n - 1):
		last = member[-1]
		upper_bound = (1 - last)*deviation*(n + 1 - i)/(n + 1) + last
		lower_bound = last - last*deviation*(i + 1)/(n + 1)
		value = (upper_bound - lower_bound)*random() + lower_bound
		member.append(value)
	population.append(member)
bound = [(0, 1)]*n
values = {}
for membernum, member in enumerate(population):
	first_line = open("./output/" + str(membernum) + ".txt", "w")
	first_line.write(str(call.call(member)) + "\n")
	first_line.close()
	result = minimize(fun=f, x0=member, args=([membernum]), method="TNC", bounds=bound)
	values[membernum] = -result.fun
best = -1
points = [-1]
for membernum, member in enumerate(population):
	if values[membernum] > best:
		best = values[member]
		points = member

print "\n\n\n"
print "BEST VALUE"
print best
print "BEST POINTS"
print points
