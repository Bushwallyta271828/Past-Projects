from __future__ import division
from pylab import *
import call
import time

n = 50
test = [(1 - i/n) for i in range(n)]
times = []
reses = []
for res in range(50, 80):
	start = time.time()
	call.call(test, res)
	stop = time.time()
	times.append(stop - start)
	reses.append(res)
plot(reses, times)
show()
