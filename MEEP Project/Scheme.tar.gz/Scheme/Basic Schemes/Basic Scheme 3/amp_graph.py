from __future__ import division
from pylab import *

args = sys.argv
if len(args) == 1:
	n = 0
else:
	n = int(args[1])
f = open("./output/output" + str(n) + "values.txt")
lines = f.readlines()
f.close()
values = []
for line in lines[1:]:
	real_line = line[:-1]
	value = float(real_line)
	values.append(value)
plot(values)
show()

plot(log(values))
show()
