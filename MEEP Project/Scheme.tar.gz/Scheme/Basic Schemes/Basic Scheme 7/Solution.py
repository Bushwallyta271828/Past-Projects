from __future__ import division
from pylab import *
import call
from scipy.optimize import minimize
import fun_gen
import threading
import time

class Solution:
	def __init__(self, points):
		self.points = points

	def merge(self, other):
		new_points = []
		spoints = self.points
		opoints = other.points
		length = len(spoints)
		for pointnum, spoint in enumerate(spoints):
			opoint = opoints[pointnum]
			new_point = (pointnum / (length - 1)) * (opoint - spoint) + spoint
			new_points.append(new_point)
		new_solution  = Solution(new_points)
		return new_solution

	def evaluate(self, *args):
		appendable = args[0]
		amplification = call.call(self.points)
		if appendable != None:
			f = open("./output/values_log_" + appendable + ".txt", "a")
		else:
			f = open("./output/values_log.txt", "a")
		f.write(str(amplification) + " " + str(self.points) + "\n")
		f.close()
		return -amplification

	def optimize(self, max_time=None, appendable=None):
		x0 = self.points
		domain = [(0, 1) for i in range(len(x0))]
		if max_iters == None:
			result = minimize(lambda points : Solution(points).evaluate(), x0, args=(appendable,), method="TNC", bounds=domain)
		else:
			result = minimize(lambda points : Solution(points).evaluate(), x0, args=(appendable,), method="TNC", bounds=domain)
		new_points = result.x
		new_solution = Solution(new_points)
		self = new_solution
